function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5ftFdwK3nzr":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

